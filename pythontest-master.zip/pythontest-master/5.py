letter_digit = {
    'A': 2,
    'B': 2,
    'C': 2,
    'D': 3,
    'E': 3,
    'F': 3,
    'G': 4,
    'H': 4,
    'I': 4,
    'J': 5,
    'K': 5,
    'L': 5,
    'М': 6,
    'N': 6,
    'O': 6,
    'S': 7,
    'R': 7,
    'Q': 7,
    'P': 7,
    'V': 8,
    'U': 8,
    'T': 8,
    'Z': 9,
    'У': 9,
    'X': 9,
    'W': 9,
}
number = input()
numbers= ''
for num in number:
    if num in letter_digit:
        numbers += str(letter_digit[num])
    else:
        numbers += num
print(numbers)
