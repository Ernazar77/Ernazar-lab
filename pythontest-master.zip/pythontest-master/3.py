#entered date dd/mm/yyyy format
import datetime
day, month, year = input("date: ").split('/')
date = datetime.datetime(int(year), int(month), int(day))
print(date)