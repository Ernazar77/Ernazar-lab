#Sum of digits
nums = input()
print(sum(int(num) for num in nums))
