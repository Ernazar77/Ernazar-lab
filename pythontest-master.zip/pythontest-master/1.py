import re

# initials
name = input()
initials = re.findall("[A-Z']", name)
print(*initials, sep='.', end='.')
