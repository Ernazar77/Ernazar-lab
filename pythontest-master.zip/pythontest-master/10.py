"""Самый частотный символ. Напишите программу, которая предоставляет пользователю
возможность ввести строковое значение и выводит на экран символ, который
появляется в нем наиболее часто."""
counter = {}
text = input()
for sym in text:
    counter[sym] = counter.get(sym, 0) + 1
highest = None
for key, value in counter.items():
    if highest is None or value > highest[1]:
        highest = (key, value)
print(*highest)